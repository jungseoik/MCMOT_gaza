﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;

namespace TravelDistance_Analyzer
{
    public class EvacRouteCommands
    {
        private const double CELL_SIZE = 50;
        private const double CLEARANCE = 304.8;

        private bool[,] _obstacleGrid;
        private Point3d _minPt;

        // ================================================================
        // 기존 커맨드: 지정한 Occupant 꼭짓점 기준 경로 탐색
        // ================================================================
        [CommandMethod("EVAC_Occupant")]
        public void FindWorstEvacRoute()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptPointResult pt1Result = ed.GetPoint("\n탐색 범위 첫 번째 코너: ");
            if (pt1Result.Status != PromptStatus.OK) return;

            PromptCornerOptions cornerOpts = new PromptCornerOptions("\n반대쪽 코너: ", pt1Result.Value);
            PromptPointResult pt2Result = ed.GetCorner(cornerOpts);
            if (pt2Result.Status != PromptStatus.OK) return;

            Point3d minPt = new Point3d(
                Math.Min(pt1Result.Value.X, pt2Result.Value.X),
                Math.Min(pt1Result.Value.Y, pt2Result.Value.Y), 0);
            Point3d maxPt = new Point3d(
                Math.Max(pt1Result.Value.X, pt2Result.Value.X),
                Math.Max(pt1Result.Value.Y, pt2Result.Value.Y), 0);

            int cols = (int)Math.Ceiling((maxPt.X - minPt.X) / CELL_SIZE);
            int rows = (int)Math.Ceiling((maxPt.Y - minPt.Y) / CELL_SIZE);
            ed.WriteMessage($"\nGrid 크기: {cols} x {rows}");

            if (cols * rows > 5_000_000)
            {
                ed.WriteMessage("\n범위가 너무 넓습니다.");
                return;
            }

            PromptDoubleOptions distOpts = new PromptDoubleOptions(
                "\n기준 피난거리 입력 (단위: m): ")
            {
                AllowNegative = false,
                AllowZero = false,
                DefaultValue = 30.0
            };
            PromptDoubleResult distResult = ed.GetDouble(distOpts);
            if (distResult.Status != PromptStatus.OK) return;

            double thresholdMm = distResult.Value * 1000.0;

            PromptDoubleOptions textHOpts = new PromptDoubleOptions("\n거리 텍스트 높이 입력 (단위: mm): ")
            {
                AllowNegative = false,
                AllowZero = false,
                DefaultValue = 750.0
            };
            PromptDoubleResult textHResult = ed.GetDouble(textHOpts);
            if (textHResult.Status != PromptStatus.OK) return;
            double textHeight = textHResult.Value;

            ed.WriteMessage($"\n기준값: {distResult.Value:F1}m ({thresholdMm:F0}mm)");

            List<Point2d> exitPoints = GetExitPoints(db, ed)
                .Where(p => p.X >= minPt.X && p.X <= maxPt.X && p.Y >= minPt.Y && p.Y <= maxPt.Y)
                .ToList();
            if (exitPoints.Count == 0) { ed.WriteMessage("\n탐색 범위 내 Evac_Exit 없음."); return; }
            ed.WriteMessage($"\n피난계단 {exitPoints.Count}개 발견.");

            List<(int col, int row)> exitCells = exitPoints
                .Select(p => WorldToGrid(p.X, p.Y, minPt))
                .Where(c => c.col >= 0 && c.col < cols && c.row >= 0 && c.row < rows)
                .Distinct().ToList();

            List<Point2d> occupantPoints = GetOccupantVertices(db, ed, minPt, maxPt);
            if (occupantPoints.Count == 0) { ed.WriteMessage("\nEvac_Occupant 없음."); return; }
            ed.WriteMessage($"\n검토 꼭짓점 {occupantPoints.Count}개.");

            ed.WriteMessage("\n장애물 수집 중...");
            List<(Point2d s, Point2d e)> segments = CollectObstacles(db, ed);

            ed.WriteMessage("\n장애물 Grid 생성 중...");
            bool[,] obstacleGrid = BuildObstacleGrid(segments, minPt, cols, rows, exitCells);

            _obstacleGrid = obstacleGrid;
            _minPt = minPt;

            ed.WriteMessage("\n경로 탐색 중...");
            var (distGrid, prevGrid) = RunDijkstra(obstacleGrid, exitCells, cols, rows);

            ed.WriteMessage("\n결과 계산 중...");

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                EnsureLayer(db, tr, "spPath_Fail", 1);
                EnsureLayer(db, tr, "Evac_Path_Pass", 3);
                tr.Commit();
            }

            int passCount = 0, failCount = 0, skipCount = 0;
            var results = new List<(List<Point3d> path, double distMm, bool isPass)>();

            foreach (var occupantPt in occupantPoints)
            {
                var (oc, or_) = WorldToGrid(occupantPt.X, occupantPt.Y, minPt);
                oc = Math.Max(0, Math.Min(cols - 1, oc));
                or_ = Math.Max(0, Math.Min(rows - 1, or_));

                int bestC = -1, bestR = -1;

                var visited = new bool[cols, rows];
                var queue = new Queue<(int c, int r)>();
                queue.Enqueue((oc, or_));
                visited[oc, or_] = true;

                int[] dc = { 0, 0, 1, -1, 1, 1, -1, -1 };
                int[] dr = { 1, -1, 0, 0, 1, -1, 1, -1 };

                int maxRadius = (int)Math.Ceiling(CLEARANCE * 3 / CELL_SIZE);

                while (queue.Count > 0)
                {
                    var (c, r) = queue.Dequeue();

                    if (Math.Abs(c - oc) > maxRadius || Math.Abs(r - or_) > maxRadius) continue;

                    if (!obstacleGrid[c, r] && distGrid[c, r] != double.MaxValue)
                    {
                        bestC = c; bestR = r;
                        break;
                    }

                    for (int i = 0; i < 8; i++)
                    {
                        int nc = c + dc[i], nr = r + dr[i];
                        if (nc < 0 || nc >= cols || nr < 0 || nr >= rows) continue;
                        if (visited[nc, nr]) continue;
                        visited[nc, nr] = true;
                        queue.Enqueue((nc, nr));
                    }
                }

                if (bestC == -1)
                {
                    skipCount++;
                    continue;
                }

                double distMm = distGrid[bestC, bestR];
                bool isPass = distMm <= thresholdMm;
                List<Point3d> path = TracePath(prevGrid, bestC, bestR, minPt);

                if (path.Count >= 2)
                    results.Add((path, distMm, isPass));

                if (isPass) passCount++;
                else failCount++;
            }

            ed.WriteMessage("\n결과 그리는 중...");
            DrawAllResults(db, results, textHeight);

            if (skipCount > 0)
                ed.WriteMessage($"\n도달 불가 꼭짓점 {skipCount}개 스킵.");

            ed.WriteMessage($"\n\n========== 결과 요약 ==========");
            ed.WriteMessage($"\n기준값       : {distResult.Value:F1}m");
            ed.WriteMessage($"\n Pass (초록) : {passCount}개");
            ed.WriteMessage($"\n Fail (빨강) : {failCount}개");
            ed.WriteMessage($"\n 도달 불가   : {skipCount}개");
            ed.WriteMessage($"\n================================");
            ed.WriteMessage("\n완료! 'Evac_Path_Pass' / 'Evac_Path_Fail' 레이어에 결과가 그려졌습니다.");
        }

        // ================================================================
        // 신규 커맨드: 전체 범위 멀티해상도 탐색 → 구획별 Worst 5
        // ================================================================
        [CommandMethod("EVAC_WorstN")]
        public void FindWorstNEvacRoute()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptPointResult pt1Result = ed.GetPoint("\n탐색 범위 첫 번째 코너: ");
            if (pt1Result.Status != PromptStatus.OK) return;

            PromptCornerOptions cornerOpts = new PromptCornerOptions("\n반대쪽 코너: ", pt1Result.Value);
            PromptPointResult pt2Result = ed.GetCorner(cornerOpts);
            if (pt2Result.Status != PromptStatus.OK) return;

            Point3d minPt = new Point3d(
                Math.Min(pt1Result.Value.X, pt2Result.Value.X),
                Math.Min(pt1Result.Value.Y, pt2Result.Value.Y), 0);
            Point3d maxPt = new Point3d(
                Math.Max(pt1Result.Value.X, pt2Result.Value.X),
                Math.Max(pt1Result.Value.Y, pt2Result.Value.Y), 0);

            PromptIntegerOptions worstOpts = new PromptIntegerOptions("\nWorst 개수 입력 (1~50): ")
            {
                AllowNegative = false,
                AllowZero = false,
                DefaultValue = 5,
                LowerLimit = 1,
                UpperLimit = 50
            };
            PromptIntegerResult worstResult = ed.GetInteger(worstOpts);
            if (worstResult.Status != PromptStatus.OK) return;

            int worstCount = worstResult.Value;
            ed.WriteMessage($"\nWorst {worstCount}개소 탐색.");

            PromptDoubleOptions distOpts = new PromptDoubleOptions("\n기준 피난거리 입력 (단위: m): ")
            {
                AllowNegative = false,
                AllowZero = false,
                DefaultValue = 30.0
            };
            PromptDoubleResult distResult = ed.GetDouble(distOpts);
            if (distResult.Status != PromptStatus.OK) return;

            double thresholdMm = distResult.Value * 1000.0;

            PromptDoubleOptions textHOpts = new PromptDoubleOptions("\n거리 텍스트 높이 입력 (단위: mm): ")
            {
                AllowNegative = false,
                AllowZero = false,
                DefaultValue = 750.0
            };
            PromptDoubleResult textHResult = ed.GetDouble(textHOpts);
            if (textHResult.Status != PromptStatus.OK) return;
            double textHeight = textHResult.Value;

            ed.WriteMessage($"\n기준값: {distResult.Value:F1}m ({thresholdMm:F0}mm)");

            // ── 장애물 수집 ──────────────────────────────────────────
            ed.WriteMessage("\n장애물 수집 중...");
            List<(Point2d s, Point2d e)> segments = CollectObstacles(db, ed);

            List<Point2d> exitPoints = GetExitPoints(db, ed)
                .Where(p => p.X >= minPt.X && p.X <= maxPt.X && p.Y >= minPt.Y && p.Y <= maxPt.Y)
                .ToList();
            if (exitPoints.Count == 0) { ed.WriteMessage("\n탐색 범위 내 Evac_Exit 없음."); return; }
            ed.WriteMessage($"\n피난계단 {exitPoints.Count}개 발견.");

            // ── Phase 1: 저해상도(큰 셀)로 전체 탐색 ─────────────────
            double coarseCell = CELL_SIZE * 10;   // 500mm 셀
            int cCols = (int)Math.Ceiling((maxPt.X - minPt.X) / coarseCell);
            int cRows = (int)Math.Ceiling((maxPt.Y - minPt.Y) / coarseCell);
            ed.WriteMessage($"\n[Phase1] 저해상도 Grid: {cCols} x {cRows}");

            List<(int col, int row)> coarseExitCells = exitPoints
                .Select(p => WorldToGrid2(p.X, p.Y, minPt, coarseCell))
                .Where(c => c.col >= 0 && c.col < cCols && c.row >= 0 && c.row < cRows)
                .Distinct().ToList();

            bool[,] coarseObstacle = BuildObstacleGrid2(segments, minPt, cCols, cRows, coarseExitCells, coarseCell);
            var (coarseDist, _) = RunDijkstra2(coarseObstacle, coarseExitCells, cCols, cRows, coarseCell);

            // 저해상도에서 거리 상위 20% 셀 후보 추출
            var coarseCandidates = new List<(int c, int r, double d)>();
            for (int c = 0; c < cCols; c++)
                for (int r = 0; r < cRows; r++)
                    if (!coarseObstacle[c, r] && coarseDist[c, r] != double.MaxValue)
                        coarseCandidates.Add((c, r, coarseDist[c, r]));

            if (coarseCandidates.Count == 0) { ed.WriteMessage("\n탐색 가능한 셀 없음."); return; }

            coarseCandidates.Sort((a, b) => b.d.CompareTo(a.d));
            int topN = Math.Max(20, coarseCandidates.Count / 5);  // 상위 20%
            var topCoarse = coarseCandidates.Take(topN).ToList();
            ed.WriteMessage($"\n[Phase1] 후보 셀 {topCoarse.Count}개 추출.");

            // ── Phase 2: 고해상도(원래 셀)로 후보 영역만 정밀 탐색 ───
            int cols = (int)Math.Ceiling((maxPt.X - minPt.X) / CELL_SIZE);
            int rows = (int)Math.Ceiling((maxPt.Y - minPt.Y) / CELL_SIZE);
            ed.WriteMessage($"\n[Phase2] 고해상도 Grid: {cols} x {rows}");

            List<(int col, int row)> fineExitCells = exitPoints
                .Select(p => WorldToGrid2(p.X, p.Y, minPt, CELL_SIZE))
                .Where(c => c.col >= 0 && c.col < cols && c.row >= 0 && c.row < rows)
                .Distinct().ToList();

            bool[,] fineObstacle = BuildObstacleGrid2(segments, minPt, cols, rows, fineExitCells, CELL_SIZE);
            _obstacleGrid = fineObstacle;
            _minPt = minPt;

            var (fineDist, finePrev) = RunDijkstra2(fineObstacle, fineExitCells, cols, rows, CELL_SIZE);

            // 후보 영역(저해상도 셀 → 고해상도 셀 범위)에서 최대 거리 지점 수집
            int scale = (int)Math.Round(coarseCell / CELL_SIZE);  // 10
            var fineCandidates = new List<(int c, int r, double d)>();

            foreach (var (cc, cr, _) in topCoarse)
            {
                int fc1 = cc * scale, fc2 = Math.Min(cols - 1, fc1 + scale - 1);
                int fr1 = cr * scale, fr2 = Math.Min(rows - 1, fr1 + scale - 1);

                double localMax = double.MinValue;
                int bestC = -1, bestR = -1;

                for (int fc = fc1; fc <= fc2; fc++)
                    for (int fr = fr1; fr <= fr2; fr++)
                        if (!fineObstacle[fc, fr] && fineDist[fc, fr] != double.MaxValue)
                            if (fineDist[fc, fr] > localMax)
                            { localMax = fineDist[fc, fr]; bestC = fc; bestR = fr; }

                if (bestC != -1)
                    fineCandidates.Add((bestC, bestR, localMax));
            }

            fineCandidates.Sort((a, b) => b.d.CompareTo(a.d));

            // ── 새 코드: 보행거리 기반 분산 Top 5 ────────────────────
            // 이미 선택된 지점들로부터 보행거리가 충분히 먼 지점만 선택
            // 최소 이격거리: 전체 탐색범위 대각선의 15% 또는 고정값 중 큰 값
            double diagMm = Math.Sqrt(
                Math.Pow(maxPt.X - minPt.X, 2) +
                Math.Pow(maxPt.Y - minPt.Y, 2));
            double minSeparationMm = Math.Max(diagMm * 0.15, 5000);  // 최소 5m 이격
            ed.WriteMessage($"\n[결과] 최소 이격거리: {minSeparationMm / 1000.0:F1}m");

            var worst5 = new List<(int c, int r, double d)>();

            // 5개 미만이면 이격거리 줄여서 재시도
            while(worst5.Count < worstCount && minSeparationMm > 1000)
            {
                minSeparationMm *= 0.7;  // 30% 축소
                worst5.Clear();

                foreach (var (fc, fr, fd) in fineCandidates)
                {
                    bool tooClose = false;
                    foreach (var (sc, sr, _) in worst5)
                    {
                        double worldDist = Math.Sqrt(
                            Math.Pow((fc - sc) * CELL_SIZE, 2) +
                            Math.Pow((fr - sr) * CELL_SIZE, 2));
                        if (worldDist < minSeparationMm)
                        { tooClose = true; break; }
                    }
                    if (!tooClose)
                    {
                        worst5.Add((fc, fr, fd));
                        if (worst5.Count >= worstCount) break;
                    }
                }
                ed.WriteMessage($"\n  이격거리 재조정: {minSeparationMm / 1000.0:F1}m → {worst5.Count}개");
            }

            ed.WriteMessage($"\n[결과] 구획별 Worst {worst5.Count}개소 발견.");

            // ── 결과 그리기 ───────────────────────────────────────────
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                EnsureLayer(db, tr, "Evac_Path_Fail", 1);  // 빨강
                EnsureLayer(db, tr, "Evac_Path_Pass", 3);  // 초록
                tr.Commit();
            }

            var results = new List<(List<Point3d> path, double distMm, bool isPass)>();
            int passCount = 0, failCount = 0;
            foreach (var (fc, fr, fd) in worst5)
            {
                bool isPass = fd <= thresholdMm;
                List<Point3d> path = TracePath(finePrev, fc, fr, minPt);
                if (path.Count >= 2)
                    results.Add((path, fd, isPass));
                if (isPass) passCount++; else failCount++;
                ed.WriteMessage($"\n  Worst: {fd / 1000.0:F1}m @ Grid({fc},{fr}) [{(isPass ? "PASS" : "FAIL")}]");
            }

            DrawAllResults(db, results, textHeight);  // ← 기존 DrawAllResults 그대로 재사용

            ed.WriteMessage($"\n\n========== 결과 요약 ==========");
            ed.WriteMessage($"\n기준값       : {distResult.Value:F1}m");
            ed.WriteMessage($"\n Pass (초록) : {passCount}개");
            ed.WriteMessage($"\n Fail (빨강) : {failCount}개");
            ed.WriteMessage($"\n================================");
            ed.WriteMessage("\n완료! 'Evac_Path_Pass' / 'Evac_Path_Fail' 레이어에 결과가 그려졌습니다.");
        }

        // ================================================================
        // 모든 결과 일괄 그리기 (EVAC_Occupant용)
        // ================================================================
        private void DrawAllResults(
            Database db,
            List<(List<Point3d> path, double distMm, bool isPass)> results, double textHeight)
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord msp = tr.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(db),
                    OpenMode.ForWrite) as BlockTableRecord;

                var colorByLayer = Autodesk.AutoCAD.Colors.Color.FromColorIndex(
                    Autodesk.AutoCAD.Colors.ColorMethod.ByLayer, 256);

                foreach (var (path, distMm, isPass) in results)
                {
                    string layerName = isPass ? "Evac_Path_Pass" : "Evac_Path_Fail";
                    Point3d startPt = path[0];

                    Polyline pline = new Polyline { Layer = layerName };
                    pline.Color = colorByLayer;
                    for (int i = 0; i < path.Count; i++)
                        pline.AddVertexAt(i, new Point2d(path[i].X, path[i].Y), 0, 0, 0);

                    ObjectId polyId = msp.AppendEntity(pline);
                    tr.AddNewlyCreatedDBObject(pline, true);

                    Circle circle = new Circle(startPt, Vector3d.ZAxis, CELL_SIZE * 1.5)
                    { Layer = layerName };
                    circle.Color = colorByLayer;
                    msp.AppendEntity(circle);
                    tr.AddNewlyCreatedDBObject(circle, true);

                    string polyIdStr = polyId.OldIdPtr.ToInt64().ToString();
                    string fieldCode = "%<\\AcObjProp Object(%<\\_ObjId " + polyIdStr + ">%).Length \\f \"%lu2%pr1%ct8[0.001]%ps[,m]\">%";

                    Point3d textPos = new Point3d(
                        startPt.X + CELL_SIZE * 2.0,
                        startPt.Y + CELL_SIZE * 0.5, 0);

                    double distM = Math.Round(distMm / 1000.0, 1);
                    string labelText = $"{distM:F1}m";

                    double charWidth = textHeight * 0.7;  // 0.9 → 0.7
                    double textW = labelText.Length * charWidth;
                    double padL = textHeight * 0.2;       // 0.3 → 0.2
                    double padR = textHeight * 0.1;       // 0.3 → 0.1
                    double padB = textHeight * 0.2;
                    double wipeW = textW + padL + padR;
                    double wipeH = textHeight * 1.6;

                    var wipeoutPts = new Point2dCollection(new[]
                    {
                        new Point2d(textPos.X - padL,         textPos.Y - padB),
                        new Point2d(textPos.X - padL + wipeW, textPos.Y - padB),
                        new Point2d(textPos.X - padL + wipeW, textPos.Y - padB + wipeH),
                        new Point2d(textPos.X - padL,         textPos.Y - padB + wipeH),
                        new Point2d(textPos.X - padL,         textPos.Y - padB),
                    });
                    Wipeout wipeout = new Wipeout();
                    wipeout.SetDatabaseDefaults();
                    wipeout.SetFrom(wipeoutPts, Vector3d.ZAxis);
                    wipeout.Layer = layerName;
                    wipeout.Color = colorByLayer;
                    msp.AppendEntity(wipeout);
                    tr.AddNewlyCreatedDBObject(wipeout, true);

                    DBText text = new DBText();
                    text.SetDatabaseDefaults();
                    text.Color = colorByLayer;
                    text.Position = textPos;
                    text.TextString = fieldCode;
                    text.Height = textHeight;
                    text.WidthFactor = 0.80;
                    text.Layer = layerName;
                    msp.AppendEntity(text);
                    tr.AddNewlyCreatedDBObject(text, true);
                }

                db.EvaluateFields();
                tr.Commit();
            }
        }

        // ================================================================
        // Worst 5 결과 그리기 (EVAC_WorstN용)
        // ================================================================
        private void DrawWorst5Results(
            Database db,
            List<(List<Point3d> path, double distMm, bool isPass)> results, double textHeight)
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord msp = tr.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(db),
                    OpenMode.ForWrite) as BlockTableRecord;

                var colorByLayer = Autodesk.AutoCAD.Colors.Color.FromColorIndex(
                    Autodesk.AutoCAD.Colors.ColorMethod.ByLayer, 256);

                int rank = 1;
                foreach (var (path, distMm, _) in results)
                {
                    string layerName = "Evac_Worst5";
                    Point3d startPt = path[0];

                    Polyline pline = new Polyline { Layer = layerName };
                    pline.Color = colorByLayer;
                    for (int i = 0; i < path.Count; i++)
                        pline.AddVertexAt(i, new Point2d(path[i].X, path[i].Y), 0, 0, 0);

                    ObjectId polyId = msp.AppendEntity(pline);
                    tr.AddNewlyCreatedDBObject(pline, true);

                    Circle circle = new Circle(startPt, Vector3d.ZAxis, CELL_SIZE * 1.5)
                    { Layer = layerName };
                    circle.Color = colorByLayer;
                    msp.AppendEntity(circle);
                    tr.AddNewlyCreatedDBObject(circle, true);

                    double distM = Math.Round(distMm / 1000.0, 1);
                    string labelText = $"#{rank} {distM:F1}m";

                    double charWidth = textHeight * 0.7;  // 0.9 → 0.7
                    double textW = labelText.Length * charWidth;
                    double padL = textHeight * 0.2;       // 0.3 → 0.2
                    double padR = textHeight * 0.1;       // 0.3 → 0.1
                    double padB = textHeight * 0.2;
                    double wipeW = textW + padL + padR;
                    double wipeH = textHeight * 1.6;

                    Point3d textPos = new Point3d(
                        startPt.X + CELL_SIZE * 2.0,
                        startPt.Y + CELL_SIZE * 0.5, 0);

                    var wipeoutPts = new Point2dCollection(new[]
                    {
                        new Point2d(textPos.X - padL,         textPos.Y - padB),
                        new Point2d(textPos.X - padL + wipeW, textPos.Y - padB),
                        new Point2d(textPos.X - padL + wipeW, textPos.Y - padB + wipeH),
                        new Point2d(textPos.X - padL,         textPos.Y - padB + wipeH),
                        new Point2d(textPos.X - padL,         textPos.Y - padB),
                    });
                    Wipeout wipeout = new Wipeout();
                    wipeout.SetDatabaseDefaults();
                    wipeout.SetFrom(wipeoutPts, Vector3d.ZAxis);
                    wipeout.Layer = layerName;
                    wipeout.Color = colorByLayer;
                    msp.AppendEntity(wipeout);
                    tr.AddNewlyCreatedDBObject(wipeout, true);

                    string polyIdStr = polyId.OldIdPtr.ToInt64().ToString();
                    string fieldCode = $"#{rank} " + "%<\\AcObjProp Object(%<\\_ObjId "
                        + polyIdStr + ">%).Length \\f \"%lu2%pr1%ct8[0.001]%ps[,m]\">%";

                    DBText text = new DBText();
                    text.SetDatabaseDefaults();
                    text.Color = colorByLayer;
                    text.Position = textPos;
                    text.TextString = fieldCode;
                    text.Height = textHeight;
                    text.WidthFactor = 0.80;
                    text.Layer = layerName;
                    msp.AppendEntity(text);
                    tr.AddNewlyCreatedDBObject(text, true);

                    rank++;
                }

                db.EvaluateFields();
                tr.Commit();
            }
        }

        // ================================================================
        // 연결 컴포넌트 분석 (FloodFill BFS) - 공간 구획 구분용
        // ================================================================
        private int[] BuildConnectedComponents(bool[,] obstacle, int cols, int rows)
        {
            int[] comp = new int[cols * rows];
            for (int i = 0; i < comp.Length; i++) comp[i] = -1;

            int[] dc = { 0, 0, 1, -1 };  // 4방향 연결
            int[] dr = { 1, -1, 0, 0 };

            int compId = 0;
            for (int c = 0; c < cols; c++)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (obstacle[c, r] || comp[c * rows + r] >= 0) continue;

                    var queue = new Queue<(int c, int r)>();
                    queue.Enqueue((c, r));
                    comp[c * rows + r] = compId;

                    while (queue.Count > 0)
                    {
                        var (cc, cr) = queue.Dequeue();
                        for (int i = 0; i < 4; i++)
                        {
                            int nc = cc + dc[i], nr = cr + dr[i];
                            if (nc < 0 || nc >= cols || nr < 0 || nr >= rows) continue;
                            if (obstacle[nc, nr] || comp[nc * rows + nr] >= 0) continue;
                            comp[nc * rows + nr] = compId;
                            queue.Enqueue((nc, nr));
                        }
                    }
                    compId++;
                }
            }
            return comp;
        }

        // ================================================================
        // 장애물 수집: Block 재귀 분해로 실제 선분 추출
        // ================================================================
        private List<(Point2d s, Point2d e)> CollectObstacles(Database db, Editor ed)
        {
            var segments = new List<(Point2d, Point2d)>();
            var skipLayers = new HashSet<string>
            {
                "Evac_Exit",
                "Evac_Occupant",
                "Evac_Path_Pass",
                "Evac_Path_Fail",
                "Evac_Worst5"
            };

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord msp = tr.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(db),
                    OpenMode.ForRead) as BlockTableRecord;

                foreach (ObjectId id in msp)
                {
                    Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
                    if (ent == null || ent.IsErased) continue;
                    if (skipLayers.Contains(ent.Layer)) continue;

                    if (ent is Hatch) continue;

                    if (ent is BlockReference br)
                        ExtractSegmentsFromBlock(db, tr, br, br.BlockTransform,
                            segments, skipLayers, 0);
                    else
                        ExtractSegmentsFromEntity(ent, Matrix3d.Identity, segments);
                }

                tr.Commit();
            }

            ed.WriteMessage($"\n  선분 {segments.Count}개 수집.");
            return segments;
        }

        // ================================================================
        // Block 재귀 분해 (변환 행렬 누적)
        // ================================================================
        private void ExtractSegmentsFromBlock(
            Database db, Transaction tr,
            BlockReference br, Matrix3d transform,
            List<(Point2d, Point2d)> segments,
            HashSet<string> skipLayers,
            int depth)
        {
            if (depth > 10) return;

            BlockTableRecord btr;
            try { btr = tr.GetObject(br.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord; }
            catch { return; }
            if (btr == null) return;

            foreach (ObjectId childId in btr)
            {
                Entity child;
                try { child = tr.GetObject(childId, OpenMode.ForRead) as Entity; }
                catch { continue; }
                if (child == null || child.IsErased) continue;

                if (child is BlockReference childBr)
                {
                    Matrix3d childTransform = transform * childBr.BlockTransform;
                    ExtractSegmentsFromBlock(db, tr, childBr, childTransform,
                        segments, skipLayers, depth + 1);
                }
                else
                {
                    ExtractSegmentsFromEntity(child, transform, segments);
                }
            }
        }

        // ================================================================
        // Entity → 선분 추출 (변환 행렬 적용)
        // ================================================================
        private void ExtractSegmentsFromEntity(
            Entity ent, Matrix3d transform,
            List<(Point2d, Point2d)> segments)
        {
            if (ent is Line ln)
            {
                Point3d s = ln.StartPoint.TransformBy(transform);
                Point3d e = ln.EndPoint.TransformBy(transform);
                segments.Add((new Point2d(s.X, s.Y), new Point2d(e.X, e.Y)));
            }
            else if (ent is Polyline pl)
            {
                int n = pl.NumberOfVertices;
                for (int i = 0; i < n - 1; i++)
                {
                    Point3d s = pl.GetPoint3dAt(i).TransformBy(transform);
                    Point3d e = pl.GetPoint3dAt(i + 1).TransformBy(transform);
                    segments.Add((new Point2d(s.X, s.Y), new Point2d(e.X, e.Y)));
                }
                if (pl.Closed)
                {
                    Point3d s = pl.GetPoint3dAt(n - 1).TransformBy(transform);
                    Point3d e = pl.GetPoint3dAt(0).TransformBy(transform);
                    segments.Add((new Point2d(s.X, s.Y), new Point2d(e.X, e.Y)));
                }
            }
            else if (ent is Polyline2d pl2)
            {
                try
                {
                    Extents3d ext = ent.GeometricExtents;
                    Point3d p1 = new Point3d(ext.MinPoint.X, ext.MinPoint.Y, 0).TransformBy(transform);
                    Point3d p2 = new Point3d(ext.MaxPoint.X, ext.MinPoint.Y, 0).TransformBy(transform);
                    Point3d p3 = new Point3d(ext.MaxPoint.X, ext.MaxPoint.Y, 0).TransformBy(transform);
                    Point3d p4 = new Point3d(ext.MinPoint.X, ext.MaxPoint.Y, 0).TransformBy(transform);
                    segments.Add((new Point2d(p1.X, p1.Y), new Point2d(p2.X, p2.Y)));
                    segments.Add((new Point2d(p2.X, p2.Y), new Point2d(p3.X, p3.Y)));
                    segments.Add((new Point2d(p3.X, p3.Y), new Point2d(p4.X, p4.Y)));
                    segments.Add((new Point2d(p4.X, p4.Y), new Point2d(p1.X, p1.Y)));
                }
                catch { }
            }
            else if (ent is Arc arc)
            {
                int div = 12;
                double startAngle = arc.StartAngle;
                double endAngle = arc.EndAngle;
                if (endAngle < startAngle) endAngle += Math.PI * 2;

                Point3d prev = (arc.Center +
                    new Vector3d(Math.Cos(startAngle), Math.Sin(startAngle), 0) * arc.Radius)
                    .TransformBy(transform);

                for (int i = 1; i <= div; i++)
                {
                    double angle = startAngle + (endAngle - startAngle) * i / div;
                    Point3d curr = (arc.Center +
                        new Vector3d(Math.Cos(angle), Math.Sin(angle), 0) * arc.Radius)
                        .TransformBy(transform);
                    segments.Add((new Point2d(prev.X, prev.Y), new Point2d(curr.X, curr.Y)));
                    prev = curr;
                }
            }
            else if (ent is Circle circ)
            {
                int div = 16;
                Point3d center = circ.Center.TransformBy(transform);
                double radius = circ.Radius * transform.GetScale();

                Point3d prev = new Point3d(center.X + radius, center.Y, 0);
                for (int i = 1; i <= div; i++)
                {
                    double angle = Math.PI * 2 * i / div;
                    Point3d curr = new Point3d(
                        center.X + Math.Cos(angle) * radius,
                        center.Y + Math.Sin(angle) * radius, 0);
                    segments.Add((new Point2d(prev.X, prev.Y), new Point2d(curr.X, curr.Y)));
                    prev = curr;
                }
            }
            else
            {
                try
                {
                    Extents3d ext = ent.GeometricExtents;
                    Point3d p1 = new Point3d(ext.MinPoint.X, ext.MinPoint.Y, 0).TransformBy(transform);
                    Point3d p2 = new Point3d(ext.MaxPoint.X, ext.MinPoint.Y, 0).TransformBy(transform);
                    Point3d p3 = new Point3d(ext.MaxPoint.X, ext.MaxPoint.Y, 0).TransformBy(transform);
                    Point3d p4 = new Point3d(ext.MinPoint.X, ext.MaxPoint.Y, 0).TransformBy(transform);
                    segments.Add((new Point2d(p1.X, p1.Y), new Point2d(p2.X, p2.Y)));
                    segments.Add((new Point2d(p2.X, p2.Y), new Point2d(p3.X, p3.Y)));
                    segments.Add((new Point2d(p3.X, p3.Y), new Point2d(p4.X, p4.Y)));
                    segments.Add((new Point2d(p4.X, p4.Y), new Point2d(p1.X, p1.Y)));
                }
                catch { }
            }
        }

        // ================================================================
        // 장애물 Grid 생성 (기존 - CELL_SIZE 고정)
        // ================================================================
        private bool[,] BuildObstacleGrid(
            List<(Point2d s, Point2d e)> segments,
            Point3d minPt, int cols, int rows,
            List<(int col, int row)> exitCells)
        {
            return BuildObstacleGrid2(segments, minPt, cols, rows, exitCells, CELL_SIZE);
        }

        // ================================================================
        // 장애물 Grid 생성 (범용 - cellSize 파라미터)
        // ================================================================
        private bool[,] BuildObstacleGrid2(
            List<(Point2d s, Point2d e)> segments,
            Point3d minPt, int cols, int rows,
            List<(int col, int row)> exitCells,
            double cellSize)
        {
            bool[,] grid = new bool[cols, rows];
            var exitSet = new HashSet<(int, int)>(exitCells);
            double margin = CLEARANCE;

            foreach (var (s, e) in segments)
            {
                double x1 = Math.Min(s.X, e.X) - margin;
                double y1 = Math.Min(s.Y, e.Y) - margin;
                double x2 = Math.Max(s.X, e.X) + margin;
                double y2 = Math.Max(s.Y, e.Y) + margin;

                int c1 = Math.Max(0, (int)Math.Floor((x1 - minPt.X) / cellSize));
                int r1 = Math.Max(0, (int)Math.Floor((y1 - minPt.Y) / cellSize));
                int c2 = Math.Min(cols - 1, (int)Math.Floor((x2 - minPt.X) / cellSize));
                int r2 = Math.Min(rows - 1, (int)Math.Floor((y2 - minPt.Y) / cellSize));

                for (int c = c1; c <= c2; c++)
                    for (int r = r1; r <= r2; r++)
                    {
                        if (grid[c, r] || exitSet.Contains((c, r))) continue;
                        Point2d cellCenter = new Point2d(
                            minPt.X + (c + 0.5) * cellSize,
                            minPt.Y + (r + 0.5) * cellSize);
                        if (PointToSegmentDistance(cellCenter, s, e) < CLEARANCE)
                            grid[c, r] = true;
                    }
            }
            return grid;
        }

        // ================================================================
        // 점 ~ 선분 최소 거리
        // ================================================================
        private double PointToSegmentDistance(Point2d p, Point2d a, Point2d b)
        {
            double dx = b.X - a.X, dy = b.Y - a.Y;
            double lenSq = dx * dx + dy * dy;
            if (lenSq < 1e-10) return p.GetDistanceTo(a);

            double t = Math.Max(0, Math.Min(1,
                ((p.X - a.X) * dx + (p.Y - a.Y) * dy) / lenSq));

            double px = a.X + t * dx, py = a.Y + t * dy;
            return Math.Sqrt((p.X - px) * (p.X - px) + (p.Y - py) * (p.Y - py));
        }

        // ================================================================
        // Multi-source Dijkstra (기존 - CELL_SIZE 고정)
        // ================================================================
        private (double[,] dist, (int, int)[,] prev) RunDijkstra(
            bool[,] obstacle, List<(int, int)> exits, int cols, int rows)
        {
            return RunDijkstra2(obstacle, exits, cols, rows, CELL_SIZE);
        }

        // ================================================================
        // Multi-source Dijkstra (범용 - cellSize 파라미터)
        // ================================================================
        private (double[,] dist, (int, int)[,] prev) RunDijkstra2(
            bool[,] obstacle, List<(int, int)> exits, int cols, int rows, double cellSize)
        {
            double[,] dist = new double[cols, rows];
            var prev = new (int, int)[cols, rows];

            for (int c = 0; c < cols; c++)
                for (int r = 0; r < rows; r++)
                { dist[c, r] = double.MaxValue; prev[c, r] = (-1, -1); }

            int[] dc = { 1, -1, 0, 0, 1, 1, -1, -1 };
            int[] dr = { 0, 0, 1, -1, 1, -1, 1, -1 };
            double[] costs = {
                cellSize, cellSize, cellSize, cellSize,
                cellSize * 1.41421356, cellSize * 1.41421356,
                cellSize * 1.41421356, cellSize * 1.41421356 };

            var pq = new SortedSet<(double d, int c, int r)>(
                Comparer<(double, int, int)>.Create((a, b) =>
                {
                    int x = a.Item1.CompareTo(b.Item1);
                    if (x != 0) return x;
                    x = a.Item2.CompareTo(b.Item2);
                    if (x != 0) return x;
                    return a.Item3.CompareTo(b.Item3);
                }));

            foreach (var (ec, er) in exits)
            {
                if (ec < 0 || ec >= cols || er < 0 || er >= rows) continue;
                dist[ec, er] = 0;
                prev[ec, er] = (ec, er);
                pq.Add((0, ec, er));
            }

            while (pq.Count > 0)
            {
                var (d, c, r) = pq.Min;
                pq.Remove(pq.Min);
                if (d > dist[c, r]) continue;

                for (int i = 0; i < 8; i++)
                {
                    int nc = c + dc[i], nr = r + dr[i];
                    if (nc < 0 || nc >= cols || nr < 0 || nr >= rows) continue;
                    if (obstacle[nc, nr]) continue;

                    double nd = dist[c, r] + costs[i];
                    if (nd < dist[nc, nr])
                    {
                        dist[nc, nr] = nd;
                        prev[nc, nr] = (c, r);
                        pq.Add((nd, nc, nr));
                    }
                }
            }

            return (dist, prev);
        }

        // ================================================================
        // 경로 역추적 + String Pulling (Bresenham 기반)
        // ================================================================
        private List<Point3d> TracePath(
            (int, int)[,] prev, int sc, int sr, Point3d minPt)
        {
            var rawPath = new List<(int c, int r)>();
            int c = sc, r = sr;
            for (int i = 0; i < 200000; i++)
            {
                rawPath.Add((c, r));
                var (pc, pr) = prev[c, r];
                if (pc == -1 || (pc == c && pr == r)) break;
                c = pc; r = pr;
            }

            if (rawPath.Count < 2)
                return rawPath.Select(p => GridToWorld(p.c, p.r, minPt)).ToList();

            var smoothed = new List<(int c, int r)>();
            smoothed.Add(rawPath[0]);

            int anchor = 0;
            while (anchor < rawPath.Count - 1)
            {
                int farthest = anchor + 1;
                for (int i = anchor + 2; i < rawPath.Count; i++)
                {
                    if (HasLineOfSight(rawPath[anchor], rawPath[i]))
                        farthest = i;
                    else
                        break;
                }
                smoothed.Add(rawPath[farthest]);
                anchor = farthest;
            }

            return smoothed.Select(p => GridToWorld(p.c, p.r, minPt)).ToList();
        }

        // ================================================================
        // 시야 확인 (Bresenham + 대각선 코너 커팅 방지)
        // ================================================================
        private bool HasLineOfSight((int c, int r) a, (int c, int r) b)
        {
            int c0 = a.c, r0 = a.r;
            int c1 = b.c, r1 = b.r;

            int dc = Math.Abs(c1 - c0), dr = Math.Abs(r1 - r0);
            int sc = c0 < c1 ? 1 : -1;
            int sr = r0 < r1 ? 1 : -1;
            int err = dc - dr;

            while (true)
            {
                if (_obstacleGrid[c0, r0]) return false;

                if (c0 != c1 && r0 != r1)
                {
                    if (_obstacleGrid[c0 + sc, r0] && _obstacleGrid[c0, r0 + sr])
                        return false;
                }

                if (c0 == c1 && r0 == r1) break;

                int e2 = 2 * err;
                if (e2 > -dr) { err -= dr; c0 += sc; }
                if (e2 < dc) { err += dc; r0 += sr; }
            }

            return true;
        }

        // ================================================================
        // Evac_Exit Line 중심점 수집
        // ================================================================
        private List<Point2d> GetExitPoints(Database db, Editor ed)
        {
            var exits = new List<Point2d>();
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord msp = tr.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(db),
                    OpenMode.ForRead) as BlockTableRecord;

                foreach (ObjectId id in msp)
                {
                    Line line = tr.GetObject(id, OpenMode.ForRead) as Line;
                    if (line == null || line.IsErased || line.Layer != "Evac_Exit") continue;

                    Point2d mid = new Point2d(
                        (line.StartPoint.X + line.EndPoint.X) / 2.0,
                        (line.StartPoint.Y + line.EndPoint.Y) / 2.0);
                    exits.Add(mid);
                    ed.WriteMessage($"\n피난계단: ({mid.X:F0}, {mid.Y:F0})");
                }
                tr.Commit();
            }
            return exits;
        }

        // ================================================================
        // Evac_Occupant 꼭짓점 수집
        // ================================================================
        private List<Point2d> GetOccupantVertices(
            Database db, Editor ed, Point3d minPt, Point3d maxPt)
        {
            var verts = new List<Point2d>();
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord msp = tr.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(db),
                    OpenMode.ForRead) as BlockTableRecord;

                foreach (ObjectId id in msp)
                {
                    Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
                    if (ent == null || ent.IsErased || ent.Layer != "Evac_Occupant") continue;

                    var pts = new List<Point2d>();

                    if (ent is Polyline pl)
                    {
                        ed.WriteMessage($"\n[Occupant Polyline] 꼭짓점 수: {pl.NumberOfVertices}개");
                        for (int i = 0; i < pl.NumberOfVertices; i++)
                        {
                            var p = pl.GetPoint3dAt(i);
                            pts.Add(new Point2d(p.X, p.Y));
                            ed.WriteMessage($"\n  [{i}] ({p.X:F0}, {p.Y:F0})");
                        }
                    }
                    else if (ent is Polyline2d pl2)
                    {
                        int idx = 0;
                        foreach (ObjectId vid in pl2)
                        {
                            Vertex2d v = tr.GetObject(vid, OpenMode.ForRead) as Vertex2d;
                            if (v != null)
                            {
                                pts.Add(new Point2d(v.Position.X, v.Position.Y));
                                ed.WriteMessage($"\n  [2d:{idx++}] ({v.Position.X:F0}, {v.Position.Y:F0})");
                            }
                        }
                    }
                    else if (ent is Line ln)
                    {
                        pts.Add(new Point2d(ln.StartPoint.X, ln.StartPoint.Y));
                        pts.Add(new Point2d(ln.EndPoint.X, ln.EndPoint.Y));
                    }

                    foreach (var p in pts)
                    {
                        bool inRange = p.X >= minPt.X && p.X <= maxPt.X &&
                                       p.Y >= minPt.Y && p.Y <= maxPt.Y;
                        if (inRange)
                            verts.Add(p);
                        else
                            ed.WriteMessage($"\n  ⚠ 범위 밖 제외: ({p.X:F0}, {p.Y:F0})");
                    }
                }
                tr.Commit();
            }

            ed.WriteMessage($"\n최종 수집 꼭짓점: {verts.Count}개");
            return verts;
        }

        // ================================================================
        // 레이어 생성 유틸
        // ================================================================
        private void EnsureLayer(Database db, Transaction tr, string name, short colorIndex)
        {
            LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForWrite) as LayerTable;
            if (lt.Has(name)) return;
            var ltr = new LayerTableRecord
            {
                Name = name,
                Color = Autodesk.AutoCAD.Colors.Color.FromColorIndex(
                    Autodesk.AutoCAD.Colors.ColorMethod.ByAci, colorIndex)
            };
            lt.Add(ltr);
            tr.AddNewlyCreatedDBObject(ltr, true);
        }

        // ================================================================
        // 좌표 변환
        // ================================================================
        private (int col, int row) WorldToGrid(double x, double y, Point3d minPt) =>
            ((int)Math.Floor((x - minPt.X) / CELL_SIZE),
             (int)Math.Floor((y - minPt.Y) / CELL_SIZE));

        private (int col, int row) WorldToGrid2(double x, double y, Point3d minPt, double cellSize) =>
            ((int)Math.Floor((x - minPt.X) / cellSize),
             (int)Math.Floor((y - minPt.Y) / cellSize));

        private Point3d GridToWorld(int col, int row, Point3d minPt) =>
            new Point3d(
                minPt.X + (col + 0.5) * CELL_SIZE,
                minPt.Y + (row + 0.5) * CELL_SIZE, 0);
    }
}